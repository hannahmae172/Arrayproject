var wrap = document.body.querySelector(".wrap");

var array = [
  {
    name:"Bob",
    damage:2,
    health:10,
    warrior:true
     },
  {
    name:"Jerry",
    damage:1,
    health:12,
    warrior:true
  },
  {
    name:"Mavis",
    damage:2,
    health:10,
    warrior:true
  },
  {
    name:"Morty",
    damage:4,
    health:10,
    warrior:true
  },
  {
    name:"Shorty",
    damage:10,
    health:3,
    warrior:false
  },
  {
    name:"Porty",
    damage:1,
    health:14,
    warrior:true
  },{
    name:"Perry",
    damage:2,
    health:9,
    warrior:true
  },
  {
    name:"Larry",
    damage:2,
    health:17,
    warrior:false
  }
]

for(var i=0; i<array.length; i++) {

if (array[i].health >= 10 && array[i].damage >= 2 && array[i].warrior) {
  var ele = document.createElement("div");
  var eleName = document.createElement("h1");
  var eleDamage = document.createElement("h3");
  var eleHealth = document.createElement("h3");
  var eleWarrior = document.createElement("h3");
  
  const string = array[i].name;
  const substring = "a";
  
  if (string.indexOf(substring) !== -1) {
    ele.style.color = 'red';
  }
    
  eleName.innerHTML=array[i].name
  eleDamage.innerHTML="Damage: "+array[i].damage;
  eleHealth.innerHTML="Health: "+array[i].health;
  eleWarrior.innerHTML="Warrior: "+array[i].warrior;
  ele.appendChild(eleName);
  ele.appendChild(eleDamage);
  ele.appendChild(eleHealth);
  ele.appendChild(eleWarrior);
  wrap.appendChild(ele);
}
}
